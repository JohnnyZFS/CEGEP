
-- Besoin 1 : Nombre d'�tudiants inscrits dans chaque cours enseign� par le professeur.
-- Cette requ�te permet au professeur de voir combien d'�tudiants sont inscrits � chaque cours qu'il enseigne.
--Cela l'aidera � savoir la taille de ses classes et � planifier en cons�quence.

-- Vue qui retourne le nombre d'�tudiants inscrits � chaque cours
go
CREATE VIEW Vue_Nombre_Etudiants_Cours AS
SELECT 
    c.Nom_Cours,
    COUNT(i.ID_Etudiant) AS Nombre_Etudiants
FROM 
    Cours c
LEFT JOIN 
    Inscription i ON c.ID_Cours = i.ID_Cours
GROUP BY 
    c.Nom_Cours;
go
-- Besoin 1 : Nombre d'�tudiants inscrits dans chaque cours enseign� par le professeur
SELECT 
    p.Nom AS Professeur_Nom,
    c.Nom_Cours,
    (SELECT Nombre_Etudiants 
     FROM Vue_Nombre_Etudiants_Cours 
     WHERE Nom_Cours = c.Nom_Cours) AS Nombre_Etudiants
FROM 
    Professeur p
JOIN 
    Enseignement e ON p.ID_Professeur = e.ID_Professeur
JOIN 
    Cours c ON e.ID_Cours = c.ID_Cours
ORDER BY 
    p.Nom, c.Nom_Cours;





-- Besoin 2 : Liste des cours auxquels l'�tudiant est inscrit avec la date d'inscription.
-- Cette requ�te permet � l'�tudiant de savoir dans quels cours il est inscrit et depuis quand.
--L'�tudiant souhaite obtenir la liste des cours auxquels il est inscrit, y compris la date d'inscription, 
---afin de suivre son parcours acad�mique.

SELECT 
    e.Nom AS Etudiant_Nom,
    c.Nom_Cours,
    i.Date_Inscription,
    (SELECT COUNT(*) 
     FROM Inscription i2
     WHERE i2.ID_Cours = c.ID_Cours) AS Nombre_Inscrits
FROM 
    Etudiant e
JOIN 
    Inscription i ON e.ID_Etudiant = i.ID_Etudiant
JOIN 
    Cours c ON i.ID_Cours = c.ID_Cours
WHERE 
    e.ID_Etudiant = 5 -- Remplacer par ID de l'�tudiant 
ORDER BY 
    i.Date_Inscription DESC;


-- Besoin 3 : Nombre total d'�tudiants inscrits dans tous les cours et le nombre de credits donnees
-- Cette requ�te permet � l'administration d'obtenir un aper�u du nombre d'�tudiants dans les cours et du nombre de credit donnees
--source chatgpt
SELECT 
    c.Nom_Cours,
    COUNT(i.ID_Etudiant) AS Nombre_Etudiants,
    SUM(c.Nombre_Credit) AS Total_credit_offerts
FROM 
    Cours c
JOIN 
    Inscription i ON c.ID_Cours = i.ID_Cours
GROUP BY 
    c.Nom_Cours
ORDER BY 
    Nombre_Etudiants DESC;
-- Besoin 4 : Liste des �tudiants inscrits � un cours sp�cifique, avec leur nom et leur �ge.
-- Cette requ�te permet au professeur de voir les �tudiants inscrits � son cours et leurs �ges respectifs.
--Le professeur veut obtenir la liste des �tudiants inscrits dans son cours, avec leur �ge, pour mieux comprendre son public.
---l'etudiant
SELECT 
    e.Nom AS Etudiant_Nom,
    e.Age AS Etudiant_Age,
    c.Nom_Cours,
    (SELECT AVG(e2.Age)
     FROM Etudiant e2
     JOIN Inscription i2 ON e2.ID_Etudiant = i2.ID_Etudiant
     WHERE i2.ID_Cours = c.ID_Cours) AS Age_Moyen
FROM 
    Etudiant e
JOIN 
    Inscription i ON e.ID_Etudiant = i.ID_Etudiant
JOIN 
    Cours c ON i.ID_Cours = c.ID_Cours
WHERE 
    c.ID_Cours = 4 -- Remplacer par l'ID du cours concern�
ORDER BY 
    e.Nom;

-- Besoin 5 : Trouver les cours disponibles avec une matiere en particulier par nom et le nombre d'etudiants
--pour les �tudiants et l'administration


SELECT 
    c.Nom_Cours,
    v.Nombre_Etudiants
FROM 
    Cours c
JOIN 
    Vue_Nombre_Etudiants_Cours v ON c.Nom_Cours = v.Nom_Cours

WHERE 
      c.Nom_Cours LIKE '%Anglais%' -- Remplacer par le nom de la mati�re recherch�e(Anglais,Fran�ais,Math�matiques)
ORDER BY 
    v.Nombre_Etudiants DESC;

