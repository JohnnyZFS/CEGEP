use [Cegep]
GO
GRANT VIEW DEFINITION ON ASYMMETRIC KEY::[NASKEK] TO [professeur_user]
GO
use [Cegep]
GO
GRANT CONTROL ON ASYMMETRIC KEY::[NASKEK] TO [professeur_user]
GO
use [Cegep]
GO
GRANT ALTER ON ASYMMETRIC KEY::[NASKEK] TO [professeur_user]
GO
use [Cegep]
GO
GRANT TAKE OWNERSHIP ON ASYMMETRIC KEY::[NASKEK] TO [professeur_user]
GO
use [Cegep]
GO
GRANT REFERENCES ON ASYMMETRIC KEY::[NASKEK] TO [professeur_user]
GO
use [Cegep]
GO
GRANT VIEW DEFINITION ON SYMMETRIC KEY::[NASKey] TO [professeur_user]
GO
use [Cegep]
GO
GRANT CONTROL ON SYMMETRIC KEY::[NASKey] TO [professeur_user]
GO
use [Cegep]
GO
GRANT ALTER ON SYMMETRIC KEY::[NASKey] TO [professeur_user]
GO
use [Cegep]
GO
GRANT TAKE OWNERSHIP ON SYMMETRIC KEY::[NASKey] TO [professeur_user]
GO
use [Cegep]
GO
GRANT REFERENCES ON SYMMETRIC KEY::[NASKey] TO [professeur_user]
GO
use [Cegep]
GO
GRANT VIEW DEFINITION ON [dbo].[Etudiant] TO [professeur_user]
GO
use [Cegep]
GO
GRANT VIEW CHANGE TRACKING ON [dbo].[Etudiant] TO [professeur_user]
GO
use [Cegep]
GO
GRANT REFERENCES ON [dbo].[Etudiant] TO [professeur_user]
GO
use [Cegep]
GO
GRANT SELECT ON [dbo].[Etudiant] TO [professeur_user]
GO
use [Cegep]
GO
DENY CONTROL ON [dbo].[Etudiant] TO [professeur_user]
GO
use [Cegep]
GO
DENY INSERT ON [dbo].[Etudiant] TO [professeur_user]
GO
use [Cegep]
GO
DENY UPDATE ON [dbo].[Etudiant] TO [professeur_user]
GO
use [Cegep]
GO
DENY ALTER ON [dbo].[Etudiant] TO [professeur_user]
GO
use [Cegep]
GO
DENY TAKE OWNERSHIP ON [dbo].[Etudiant] TO [professeur_user]
GO
use [Cegep]
GO
DENY DELETE ON [dbo].[Etudiant] TO [professeur_user]
GO
use [Cegep]
GO
GRANT VIEW DEFINITION ON [dbo].[Enseignement] TO [professeur_user]
GO
use [Cegep]
GO
GRANT VIEW CHANGE TRACKING ON [dbo].[Enseignement] TO [professeur_user]
GO
use [Cegep]
GO
GRANT UPDATE ON [dbo].[Enseignement] TO [professeur_user]
GO
use [Cegep]
GO
GRANT REFERENCES ON [dbo].[Enseignement] TO [professeur_user]
GO
use [Cegep]
GO
GRANT SELECT ON [dbo].[Enseignement] TO [professeur_user]
GO
use [Cegep]
GO
DENY CONTROL ON [dbo].[Enseignement] TO [professeur_user]
GO
use [Cegep]
GO
DENY INSERT ON [dbo].[Enseignement] TO [professeur_user]
GO
use [Cegep]
GO
DENY ALTER ON [dbo].[Enseignement] TO [professeur_user]
GO
use [Cegep]
GO
DENY TAKE OWNERSHIP ON [dbo].[Enseignement] TO [professeur_user]
GO
use [Cegep]
GO
DENY DELETE ON [dbo].[Enseignement] TO [professeur_user]
GO
use [Cegep]
GO
GRANT VIEW DEFINITION ON [dbo].[Professeur] TO [professeur_user]
GO
use [Cegep]
GO
GRANT VIEW CHANGE TRACKING ON [dbo].[Professeur] TO [professeur_user]
GO
use [Cegep]
GO
GRANT UPDATE ON [dbo].[Professeur] TO [professeur_user]
GO
use [Cegep]
GO
GRANT REFERENCES ON [dbo].[Professeur] TO [professeur_user]
GO
use [Cegep]
GO
GRANT SELECT ON [dbo].[Professeur] TO [professeur_user]
GO
use [Cegep]
GO
DENY CONTROL ON [dbo].[Professeur] TO [professeur_user]
GO
use [Cegep]
GO
DENY INSERT ON [dbo].[Professeur] TO [professeur_user]
GO
use [Cegep]
GO
DENY ALTER ON [dbo].[Professeur] TO [professeur_user]
GO
use [Cegep]
GO
DENY TAKE OWNERSHIP ON [dbo].[Professeur] TO [professeur_user]
GO
use [Cegep]
GO
DENY DELETE ON [dbo].[Professeur] TO [professeur_user]
GO
use [Cegep]
GO
GRANT VIEW DEFINITION ON [dbo].[Cours] TO [professeur_user]
GO
use [Cegep]
GO
GRANT VIEW CHANGE TRACKING ON [dbo].[Cours] TO [professeur_user]
GO
use [Cegep]
GO
GRANT REFERENCES ON [dbo].[Cours] TO [professeur_user]
GO
use [Cegep]
GO
GRANT SELECT ON [dbo].[Cours] TO [professeur_user]
GO
use [Cegep]
GO
DENY CONTROL ON [dbo].[Cours] TO [professeur_user]
GO
use [Cegep]
GO
DENY INSERT ON [dbo].[Cours] TO [professeur_user]
GO
use [Cegep]
GO
DENY UPDATE ON [dbo].[Cours] TO [professeur_user]
GO
use [Cegep]
GO
DENY ALTER ON [dbo].[Cours] TO [professeur_user]
GO
use [Cegep]
GO
DENY TAKE OWNERSHIP ON [dbo].[Cours] TO [professeur_user]
GO
use [Cegep]
GO
DENY DELETE ON [dbo].[Cours] TO [professeur_user]
GO
use [Cegep]
GO
GRANT VIEW DEFINITION ON [dbo].[Inscription] TO [professeur_user]
GO
use [Cegep]
GO
GRANT VIEW CHANGE TRACKING ON [dbo].[Inscription] TO [professeur_user]
GO
use [Cegep]
GO
GRANT REFERENCES ON [dbo].[Inscription] TO [professeur_user]
GO
use [Cegep]
GO
GRANT SELECT ON [dbo].[Inscription] TO [professeur_user]
GO
use [Cegep]
GO
DENY CONTROL ON [dbo].[Inscription] TO [professeur_user]
GO
use [Cegep]
GO
DENY INSERT ON [dbo].[Inscription] TO [professeur_user]
GO
use [Cegep]
GO
DENY UPDATE ON [dbo].[Inscription] TO [professeur_user]
GO
use [Cegep]
GO
DENY ALTER ON [dbo].[Inscription] TO [professeur_user]
GO
use [Cegep]
GO
DENY TAKE OWNERSHIP ON [dbo].[Inscription] TO [professeur_user]
GO
use [Cegep]
GO
DENY DELETE ON [dbo].[Inscription] TO [professeur_user]
GO
