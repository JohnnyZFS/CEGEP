use [Cegep]
GO
DENY VIEW DEFINITION ON SYMMETRIC KEY::[NASKey] TO [etudiant_user]
GO
use [Cegep]
GO
DENY CONTROL ON SYMMETRIC KEY::[NASKey] TO [etudiant_user]
GO
use [Cegep]
GO
DENY ALTER ON SYMMETRIC KEY::[NASKey] TO [etudiant_user]
GO
use [Cegep]
GO
DENY TAKE OWNERSHIP ON SYMMETRIC KEY::[NASKey] TO [etudiant_user]
GO
use [Cegep]
GO
DENY REFERENCES ON SYMMETRIC KEY::[NASKey] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT VIEW DEFINITION ON [dbo].[Enseignement] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT VIEW CHANGE TRACKING ON [dbo].[Enseignement] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT REFERENCES ON [dbo].[Enseignement] TO [etudiant_user]
GO
use [Cegep]
GO
DENY CONTROL ON [dbo].[Enseignement] TO [etudiant_user]
GO
use [Cegep]
GO
DENY INSERT ON [dbo].[Enseignement] TO [etudiant_user]
GO
use [Cegep]
GO
DENY UPDATE ON [dbo].[Enseignement] TO [etudiant_user]
GO
use [Cegep]
GO
DENY ALTER ON [dbo].[Enseignement] TO [etudiant_user]
GO
use [Cegep]
GO
DENY TAKE OWNERSHIP ON [dbo].[Enseignement] TO [etudiant_user]
GO
use [Cegep]
GO
DENY SELECT ON [dbo].[Enseignement] TO [etudiant_user]
GO
use [Cegep]
GO
DENY DELETE ON [dbo].[Enseignement] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT VIEW DEFINITION ON [dbo].[Cours] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT VIEW CHANGE TRACKING ON [dbo].[Cours] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT REFERENCES ON [dbo].[Cours] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT SELECT ON [dbo].[Cours] TO [etudiant_user]
GO
use [Cegep]
GO
DENY CONTROL ON [dbo].[Cours] TO [etudiant_user]
GO
use [Cegep]
GO
DENY INSERT ON [dbo].[Cours] TO [etudiant_user]
GO
use [Cegep]
GO
DENY UPDATE ON [dbo].[Cours] TO [etudiant_user]
GO
use [Cegep]
GO
DENY ALTER ON [dbo].[Cours] TO [etudiant_user]
GO
use [Cegep]
GO
DENY TAKE OWNERSHIP ON [dbo].[Cours] TO [etudiant_user]
GO
use [Cegep]
GO
DENY DELETE ON [dbo].[Cours] TO [etudiant_user]
GO
use [Cegep]
GO
DENY VIEW DEFINITION ON ASYMMETRIC KEY::[NASKEK] TO [etudiant_user]
GO
use [Cegep]
GO
DENY CONTROL ON ASYMMETRIC KEY::[NASKEK] TO [etudiant_user]
GO
use [Cegep]
GO
DENY ALTER ON ASYMMETRIC KEY::[NASKEK] TO [etudiant_user]
GO
use [Cegep]
GO
DENY TAKE OWNERSHIP ON ASYMMETRIC KEY::[NASKEK] TO [etudiant_user]
GO
use [Cegep]
GO
DENY REFERENCES ON ASYMMETRIC KEY::[NASKEK] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT VIEW DEFINITION ON [dbo].[Professeur] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT VIEW CHANGE TRACKING ON [dbo].[Professeur] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT REFERENCES ON [dbo].[Professeur] TO [etudiant_user]
GO
use [Cegep]
GO
DENY CONTROL ON [dbo].[Professeur] TO [etudiant_user]
GO
use [Cegep]
GO
DENY INSERT ON [dbo].[Professeur] TO [etudiant_user]
GO
use [Cegep]
GO
DENY UPDATE ON [dbo].[Professeur] TO [etudiant_user]
GO
use [Cegep]
GO
DENY ALTER ON [dbo].[Professeur] TO [etudiant_user]
GO
use [Cegep]
GO
DENY TAKE OWNERSHIP ON [dbo].[Professeur] TO [etudiant_user]
GO
use [Cegep]
GO
DENY SELECT ON [dbo].[Professeur] TO [etudiant_user]
GO
use [Cegep]
GO
DENY DELETE ON [dbo].[Professeur] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT VIEW DEFINITION ON [dbo].[Inscription] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT VIEW CHANGE TRACKING ON [dbo].[Inscription] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT INSERT ON [dbo].[Inscription] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT UPDATE ON [dbo].[Inscription] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT REFERENCES ON [dbo].[Inscription] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT SELECT ON [dbo].[Inscription] TO [etudiant_user]
GO
use [Cegep]
GO
DENY ALTER ON [dbo].[Inscription] TO [etudiant_user]
GO
use [Cegep]
GO
DENY TAKE OWNERSHIP ON [dbo].[Inscription] TO [etudiant_user]
GO
use [Cegep]
GO
DENY DELETE ON [dbo].[Inscription] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT VIEW DEFINITION ON [dbo].[Etudiant] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT VIEW CHANGE TRACKING ON [dbo].[Etudiant] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT UPDATE ON [dbo].[Etudiant] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT REFERENCES ON [dbo].[Etudiant] TO [etudiant_user]
GO
use [Cegep]
GO
GRANT SELECT ON [dbo].[Etudiant] TO [etudiant_user]
GO
use [Cegep]
GO
DENY CONTROL ON [dbo].[Etudiant] TO [etudiant_user]
GO
use [Cegep]
GO
DENY INSERT ON [dbo].[Etudiant] TO [etudiant_user]
GO
use [Cegep]
GO
DENY ALTER ON [dbo].[Etudiant] TO [etudiant_user]
GO
use [Cegep]
GO
DENY TAKE OWNERSHIP ON [dbo].[Etudiant] TO [etudiant_user]
GO
use [Cegep]
GO
DENY DELETE ON [dbo].[Etudiant] TO [etudiant_user]
GO
