use Cegep
---SOURCE : NOTE DE COURS

--L'administration a besoin de l'acces total car c'est leur base donnees et 
--doivent avoir le droit de modifier et supprimer des entites ainsi que en ajouter
-- Cr�er l'utilisateur pour l'administration
CREATE LOGIN admin_user WITH PASSWORD = 'Admin2024!'; 
CREATE USER admin_user FOR LOGIN admin_user;  

-- Attribuer un r�le d'administrateur � l'utilisateur
EXEC sp_addrolemember 'db_owner', 'admin_user';  -- R�le d'administrateur


-- Cr�er l'utilisateur pour l'�tudiant
CREATE LOGIN etudiant_user WITH PASSWORD = 'Etudiant2024!';  -- Cr�er un login avec un mot de passe s�curis�
CREATE USER etudiant_user FOR LOGIN etudiant_user;  -- Cr�er un utilisateur dans la base de donn�es



-- Cr�er l'utilisateur pour le professeur
CREATE LOGIN professeur_user WITH PASSWORD = 'Professeur2024!';  -- Cr�er un login avec un mot de passe s�curis�
CREATE USER professeur_user FOR LOGIN professeur_user;  -- Cr�er un utilisateur dans la base de donn�es


