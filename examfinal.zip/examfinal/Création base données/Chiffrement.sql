Use cegep

---	Chiffrement 
--source  notes cours

-- Voir si la Database Master Key est d�finie (DMK)
SELECT name, key_algorithm, key_length
FROM sys.symmetric_keys
WHERE name = '##MS_DatabaseMasterKey##'


-- La cr�er
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Cegep2024@';


-- L'ouvrir (au besoin)
OPEN MASTER KEY DECRYPTION BY PASSWORD = 'Cegep2024@'


-- En faire une sauvegarde
BACKUP MASTER KEY TO FILE = 'D:\sql\examfinal\master_key'  
ENCRYPTION BY PASSWORD = 'Cegep2024@'


-- Voir si la service master key (SMK) est d�finie
SELECT name, key_algorithm, key_length
FROM master.sys.symmetric_keys


-- En faire une sauvegarde
BACKUP SERVICE MASTER KEY TO FILE = 'D:\sql\examfinal\sql2022_smk'  
ENCRYPTION BY PASSWORD = 'Cegep2024@'



-- KEK : Key Encryption Key
CREATE ASYMMETRIC KEY NASKEK WITH ALGORITHM = RSA_4096


-- Cr�ation de la cl� sym�trique qui va chiffrer la colonne
CREATE SYMMETRIC KEY NASKey WITH ALGORITHM = AES_256
ENCRYPTION BY ASYMMETRIC KEY NASKEK;


-- Ouvrir la cl�
OPEN SYMMETRIC KEY NASKey
DECRYPTION BY ASYMMETRIC KEY NASKEK



-- Fermer la cl�
CLOSE SYMMETRIC KEY NASKey

-- Exemple d'insertion avec chiffrement d'une colonne (ici 'NAS')
-- La valeur de 'mon_champ' sera chiffr�e � l'insertion
GO
CREATE TRIGGER chiffrement_nas
ON Professeur
AFTER INSERT
AS
BEGIN
    UPDATE Professeur
    SET NAS = ENCRYPTBYKEY(KEY_GUID('NASKey'),inserted.NAS)
    FROM inserted
    WHERE inserted.NAS IS NOT NULL;
END;

-- Fermer la cl� sym�trique apr�s usage
CLOSE SYMMETRIC KEY NASKey;



 -- Ouvrir la cl� sym�trique NASKey pour effectuer le chiffrement
OPEN SYMMETRIC KEY NASKey DECRYPTION BY ASYMMETRIC KEY NASKEK;

go
-- Mettre � jour la colonne 'mon_champ' avec les donn�es chiffr�es
UPDATE Professeur
SET NAS = ENCRYPTBYKEY(KEY_GUID('NASKey'), NAS)
WHERE NAS IS NOT NULL;
go 
-- Fermer la cl� sym�trique apr�s l'op�ration
CLOSE SYMMETRIC KEY NASKey;


