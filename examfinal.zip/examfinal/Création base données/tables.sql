-- Cr�ation de la base de donn�es Cegep

--Groupes de personnes manipulant la base de donn�es :
--1. �tudiants : Pour consulter les cours disponibles ou v�rifier leurs cours.  
--2. Professeurs : Pour g�rer les cours qu'ils enseignent et acc�der aux informations des �tudiants inscrits.  
---3. Administration : Pour g�rer les donn�es des �tudiants, des cours et des professeurs.  

--CREATE DATABASE Cegep;
USE Cegep;

-- Table �tudiant
CREATE TABLE Etudiant (
    ID_Etudiant INT IDENTITY(1,1) PRIMARY KEY,  -- Cl� primaire
    Nom VARCHAR(255) NOT NULL,  
    Numero_carte_Etudiant VARCHAR(11) UNIQUE NOT NULL,  
    Age INT CHECK (Age >= 16) not null 
);

select * from Etudiant
-- Table Cours
CREATE TABLE Cours (
    ID_Cours INT IDENTITY(1,1) PRIMARY KEY,  -- Cl� primaire
    Nom_Cours VARCHAR(255) UNIQUE NOT NULL,  
    Numero_Certification_Accr�ditation VARCHAR(11) UNIQUE NOT NULL,  
    Nombre_Credit INT CHECK (Nombre_Credit > 0) NOT NULL 
	);
-- Table Professeur

CREATE TABLE Professeur (
    ID_Professeur INT IDENTITY(1,1) PRIMARY KEY,  -- Cl� primaire
    Nom VARCHAR(50) NOT NULL, 
    NAS VARCHAR(255) UNIQUE NOT NULL, 
    Matiere_Principale VARCHAR(50) not null 
);

-- Table Inscription (relation plusieurs � plusieurs entre �tudiant et Cours)
CREATE TABLE Inscription (
    ID_Inscription INT IDENTITY(1,1) PRIMARY KEY,  -- Cl� primaire
    ID_Etudiant INT  not null,  -- Cl� �trang�re vers �tudiant
    ID_Cours INT not null,  -- Cl� �trang�re vers Cours
    Date_Inscription DATE DEFAULT GETDATE(),  -- Date d'inscription avec valeur par d�faut � la date actuelle
    CONSTRAINT FK_Inscription_Etudiant FOREIGN KEY (ID_Etudiant) REFERENCES Etudiant(ID_Etudiant) ON DELETE CASCADE,  -- Contrainte de cl� �trang�re vers �tudiant
    CONSTRAINT FK_Inscription_Cours FOREIGN KEY (ID_Cours) REFERENCES Cours(ID_Cours) ON DELETE CASCADE -- Contrainte de cl� �trang�re vers Cours
);

-- Table Enseignement (relation plusieurs � plusieurs entre Professeur et Cours)
CREATE TABLE Enseignement (
    ID_Enseignement INT IDENTITY(1,1) PRIMARY KEY,  -- Cl� primaire
    ID_Professeur INT  not null,  -- Cl� �trang�re vers Professeur
    ID_Cours INT  not null,  -- Cl� �trang�re vers Cours
    CONSTRAINT FK_Enseignement_Professeur FOREIGN KEY (ID_Professeur) REFERENCES Professeur(ID_Professeur) ON DELETE CASCADE,  -- Contrainte de cl� �trang�re vers Professeur
    CONSTRAINT FK_Enseignement_Cours FOREIGN KEY (ID_Cours) REFERENCES Cours(ID_Cours) ON DELETE CASCADE  -- Contrainte de cl� �trang�re vers Cours
);
