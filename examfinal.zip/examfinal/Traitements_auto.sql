----TRAITEMENTS AUTMOTISEES

-- Groupe : Administration
--Besoin : Changer le nombre de credit pour un cours 
--une procedure est utliser pour faire des changements sur la base de donnees dans ce cas la table cours

-- proc�dure pour modifier le nombre de cr�dits d'un cours
CREATE PROCEDURE ModifierNombreCredits
    @ID_Cours INT,  -- L'ID du cours � mettre � jour
    @NouveauNombreCredits INT  -- Le nouveau nombre de cr�dits � d�finir pour le cours
AS
BEGIN
    -- V�rifier que le nouveau nombre de cr�dits est valide (sup�rieur � 0)
    IF @NouveauNombreCredits <= 0
    BEGIN
        PRINT 'Le nombre de cr�dits doit �tre sup�rieur � 0.'
        RETURN
    END
    
    -- Mettre � jour le nombre de cr�dits pour le cours sp�cifi�
    UPDATE Cours
    SET Nombre_Credit = @NouveauNombreCredits
    WHERE ID_Cours = @ID_Cours;

    -- V�rifier si la mise � jour a �t� effectu�e
    IF @@ROWCOUNT = 0 -- nombre lignes affectes Chatgpt(@@ROWCOUNT)
    BEGIN
        PRINT 'Aucun cours trouv� avec cet ID.'
    END
    ELSE
    BEGIN
        PRINT 'Nombre de cr�dits du cours mis � jour avec succ�s.'
    END
END;


-- Exemple d'utilisation de la proc�dure pour modifier le nombre de cr�dits
EXEC ModifierNombreCredits @ID_Cours = 1, @NouveauNombreCredits = 5;



-- Groupe : Administration et Professeur
--Besoin : afficher le NAS et le nom du professeur qui est chiffre
--Une proc�dure est utilis�e pour effectuer des actions sur les tables ou des traitements prives comme le dechiffrement et une fonction pour faire des recherches
go
CREATE OR ALTER PROCEDURE AfficherNAS
    @ProfesseurId INT
AS
SET NOCOUNT ON
BEGIN
    -- Ouvrir la cl� sym�trique pour d�chiffrer les donn�es
    OPEN SYMMETRIC KEY NASKey DECRYPTION BY ASYMMETRIC KEY NASKEK;
    SELECT 
        p.nom,
        CONVERT(VARCHAR, DECRYPTBYKEY(p.NAS)) AS NAS_dechiffre
    FROM 
        Professeur p
    WHERE 
        p.ID_Professeur = @ProfesseurId;
    -- Fermer la cl� sym�trique 
    CLOSE SYMMETRIC KEY NASKey;
END;

EXEC AfficherNAS @ProfesseurId = 224;

SELECT * FROM Professeur


go

-- Groupe : Administration
--Besoin : Supprimer automatiquement les etudiants qui depasse un certain age de admission(Les etudiant doivent mettre a jour leurs informations chaque annee)
--le declencheur permet de faire des actions automatiques apres une certaine action

-- D�clencheur pour supprimer un �tudiant lorsque son �ge d�passe 40
CREATE TRIGGER trg_SupprimerEtudiantAge
ON Etudiant
AFTER UPDATE
AS
set nocount on
BEGIN
    -- V�rifier si l'�ge de l'�tudiant dans l'enregistrement mis � jour d�passe 40
    IF EXISTS (SELECT 1 FROM inserted WHERE Age >= 50)
    BEGIN
        -- Supprimer les inscriptions li�es � cet �tudiant
        DELETE FROM Inscription
        WHERE ID_Etudiant IN (SELECT ID_Etudiant FROM inserted WHERE Age >= 50);
        
        -- Supprimer l'�tudiant de la table Etudiant
        DELETE FROM Etudiant
        WHERE ID_Etudiant IN (SELECT ID_Etudiant FROM inserted WHERE Age >= 50);
        
        PRINT '�tudiant a �t� supprim� car son �ge a d�pass� 40 ans.';
    END
END;



-- Mettre � jour l'�ge de l'�tudiant avec ID_Etudiant = 1
UPDATE Etudiant
SET Age = 51
WHERE ID_Etudiant = 1;

select *  from Etudiant where ID_Etudiant=1
